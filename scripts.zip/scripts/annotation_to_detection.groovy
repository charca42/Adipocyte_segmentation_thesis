def annotations = getAnnotationObjects()

//change this line to subset = annotations if you want to convert ALL current annotations to detections. Otherwise adjust as desired.
def subset = annotations


// Create corresponding detections (name this however you like)
def classification = getPathClass('Adipocyte')
def detections = subset.collect {
    PathObjects.createDetectionObject(it.getROI(), classification, it.getMeasurementList())
}

// Remove ellipse annotations & replace with detections
removeObjects(subset, true)
addObjects(detections)