// change the names of the classifications here to search and clear objects of the classification
selectObjectsByClassification("Negative", "Positive: Negative", "Negative: Positive")
clearSelectedObjects(true)

// this selects all objects of a certain classification. change this to be the classification that is assigned to the objects that pass the check
clearSelectedObjects(false)
selectObjectsByClassification("Positive")
